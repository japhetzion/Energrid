// Accounts.h - users, passwords and roles (the login system)
//
//   - Every user has a username, a password and a role (Viewer, Technician
//     or Admin). The role decides what the user may do (see Settings.cpp).
//   - The password is NEVER stored. What is stored is its HASH: the password
//     is mixed with a random "salt" and turned into a number that cannot be
//     turned back into the password. To log in, the typed password is hashed
//     the same way and the two hashes are compared.
//   - The users are kept in a hash table (found by username) and saved in
//     their own file, energrid_users.txt, so they survive a restart.
//
// NOTE: the hash used here is a simple one, chosen so it can be explained. A
// real system would use a proven password hash such as bcrypt or Argon2.
#ifndef ACCOUNTS_H
#define ACCOUNTS_H

#include <string>
#include <stdexcept>
#include <cstddef>
#include "Settings.h"
using namespace std;

const string USERS_FILE = "energrid_users.txt";
const int MAX_USERS = 50;

struct User {
    string name;      // always lower case
    string salt;      // random text mixed into the password before hashing
    string hash;      // the hash of salt + password
    Role role;

    User() : role(ROLE_VIEWER) {}
};

class AccountManager {
    struct UNode {
        User user;
        UNode* next;
    };
    static const int SIZE = 11;
    UNode* table[SIZE];       // hash table with chaining, like BuildingTable
    int count;
    string path;

    int bucket(const string& name) const;
    UNode* findNode(const string& name) const;
    void insertNode(const User& user);
    void clearTable();
    void saveToFile() const;
    User makeUser(const string& name, const string& password, Role role) const;

    AccountManager(const AccountManager&);
    AccountManager& operator=(const AccountManager&);

public:
    AccountManager(const string& filePath);
    ~AccountManager();

    static string normalize(const string& name);     // lower case, no spaces at the ends

    // Reads the users file. Returns false if there is no file yet.
    // Throws if the file is damaged.
    bool load();

    // Makes the three starting accounts: admin, user and viewer
    void createDefaults();

    // true if the username and password are right; the role is returned in "role"
    bool check(const string& name, const string& password, Role& role) const;

    bool exists(const string& name) const;
    int userCount() const { return count; }
    int adminCount() const;

    // These change the users and save the file straight away.
    void addUser(const string& name, const string& password, Role role);
    void removeUser(const string& name);
    void setPassword(const string& name, const string& newPassword);
    void setRole(const string& name, Role role);

    // copies the users into out[], sorted by name; returns how many
    int listUsers(User out[], int maxCount) const;
};

#endif
