// EnergyControlPage.h - MODULE 02: Energy Control
// Building management | Live monitoring (manual + live data feed) |
// Priority ranking | Power network
#ifndef ENERGYCONTROLPAGE_H
#define ENERGYCONTROLPAGE_H

#include "Page.h"
#include "PriorityQueue.h"
#include "LiveFeed.h"

class EnergyControlPage : public Page {
    // building management
    void addBuilding();
    void removeBuilding();
    void listBuildings() const;
    void compareBuildings() const;
    void showTips() const;

    // live monitoring
    void enterReading();
    void undoReading();
    void correctReading();
    void runLiveMonitor();                  // takes in live data (LiveFeed.h)
    void drawLive(const LiveMonitor& monitor, const string log[], int logSize,
                  const string& footer) const;

    // priority ranking (uses the PriorityQueue template)
    void showPriorityRanking() const;

    // power network (uses the graph)
    void showNetwork() const;
    void addNetworkLink();

    void showMenu() const;

public:
    EnergyControlPage(CampusData& d, Settings& s) : Page(d, s) {}
    string name() const { return "Energy Control"; }
    void run();
};

#endif
