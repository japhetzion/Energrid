// Ui.h - everything that makes the console look good:
// colours, boxes, bars, tables, the welcome screen and safe keyboard input.
#ifndef UI_H
#define UI_H

#include <string>
using namespace std;

const int BOX_WIDTH = 60;     // characters between the left and right border of a box

// colour codes (ANSI escape sequences)
const string RESET = "\033[0m";
const string BOLD  = "\033[1m";
const string GREY  = "\033[90m";
const string RED   = "\033[91m";
const string GREEN = "\033[92m";
const string AMBER = "\033[93m";
const string WHITE = "\033[97m";

// a middle dot, written as UTF-8 bytes so it works in any Visual Studio setting
const string DOT = "\xC2\xB7";

// ---- setup ----
void initConsole();               // switch on colours and UTF-8 in the Windows console
void clearScreen();
void cursorHome();                // move to the top-left without clearing (for live screens)
void clearBelow();                // clear everything below the cursor
bool keyPressed();                // true if the user pressed a key (does not wait)
void sleepMs(int milliseconds);   // pause the program
void setUiTheme(int theme);       // 1 = Ocean (cyan), 2 = Forest (green), 3 = Violet
string accent();                  // the accent colour of the current theme

// ---- text helpers (they ignore colour codes when measuring) ----
string paint(const string& text, const string& color);
int visibleLength(const string& s);
string padRight(const string& s, int width);
string padLeft(const string& s, int width);
string num1(double v);                          // number with 1 decimal
string statusText(const string& status);        // coloured "dot + status"
string trendText(const string& label);          // coloured arrow + RISING / FALLING / STABLE
string bar(double percent, int width, const string& color);
string sparkline(const double values[], int count, double maxValue, int width);   // tiny trend graph
string statusBar(double percent, int width);    // green / amber / red by percent

// ---- boxes ----
void drawTop(const string& title);
void drawMiddle(const string& title = "");
void drawBottom();
void drawRow(const string& text = "");
void drawRowSplit(const string& left, const string& right);
void drawCentered(const string& text);
void drawWrapped(const string& text, const string& color = "");
void drawMenuItem(const string& key, const string& label);

// ---- messages and screens ----
void showSuccess(const string& msg);
void showError(const string& msg);
void showAlert(const string& msg);
void pauseScreen(const string& msg = "Press any key to continue...");
void showWelcome();

// ---- input (every function reads a whole line) ----
int readInt(const string& prompt);
double readDouble(const string& prompt);
string readText(const string& prompt);
string readPassword(const string& prompt);   // shows * instead of the letters

#endif
