// ReportsPage.h - MODULE 04: Reports
// Select report type | Date range | Generate report | Export-ready
#ifndef REPORTSPAGE_H
#define REPORTSPAGE_H

#include <string>
#include "Page.h"
using namespace std;

const int MAX_REPORT_ROWS = MAX_BUILDINGS + 5;

// A report is a small table: 4 column headings and some rows of text.
// The same table is shown on screen and exported as a CSV file.
struct ReportTable {
    string header[4];
    string cell[MAX_REPORT_ROWS][4];
    int rows;

    ReportTable() : rows(0) {}
};

class ReportsPage : public Page {
    int reportType;      // 0 = none chosen, 1 = usage, 2 = campus summary, 3 = alerts
    int fromDay;
    int toDay;

    string reportName() const;
    string fileName() const;
    ReportTable build() const;

    void selectType();
    void setDateRange();
    void generateReport() const;
    void exportReport() const;
    void showMenu() const;

public:
    ReportsPage(CampusData& d, Settings& s) : Page(d, s), reportType(0), fromDay(1), toDay(7) {}
    string name() const { return "Reports"; }
    void run();
};

#endif
