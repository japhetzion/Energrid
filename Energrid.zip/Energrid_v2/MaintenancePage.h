// MaintenancePage.h - MODULE 03: Maintenance & Troubleshooting
// Issues | Troubleshooting | Work orders | Response
//   PriorityQueue<WorkOrder> : open work orders, most urgent first
//   Stack<WorkOrder>         : resolved work orders, newest on top (Reopen)
//   PowerGrid (graph)        : trace which buildings a fault affects
#ifndef MAINTENANCEPAGE_H
#define MAINTENANCEPAGE_H

#include <string>
#include <stdexcept>
#include "Page.h"
#include "PriorityQueue.h"
#include "Containers.h"
using namespace std;

// ---------------- Troubleshooting guide ----------------
class Troubleshooter {
public:
    static const int ISSUE_COUNT = 5;
    string issueName(int code) const;     // code 1..5, throws if unknown
    string steps(int code) const;         // the fix steps as text
};

// ---------------- Work order ----------------
struct WorkOrder {
    int id;
    string building;
    int issueCode;
    int priority;       // 1 = Low ... 5 = Critical

    WorkOrder() : id(0), issueCode(0), priority(0) {}

    // "more urgent than": higher priority first; if equal, the older order first
    bool operator>(const WorkOrder& other) const {
        if (priority != other.priority)
            return priority > other.priority;
        return id < other.id;
    }
};

string priorityName(int p);

const int MAX_ORDERS = 100;

// ---------------- The page ----------------
class MaintenancePage : public Page {
    Troubleshooter guide;
    PriorityQueue<WorkOrder, MAX_ORDERS> orders;    // open work orders
    Stack<WorkOrder> history;                       // resolved work orders
    int nextId;

    void reportIssue();
    void showGuide() const;
    void showSteps(int code, const string& title) const;
    void viewOrders() const;
    void respondToNext();
    void viewHistory() const;
    void reopenLast();
    void traceFault() const;
    void showMenu() const;

public:
    MaintenancePage(CampusData& d, Settings& s) : Page(d, s), nextId(1) {}
    string name() const { return "Maintenance & Troubleshooting"; }
    void run();

    // ---- used by Storage to save and load the work orders ----
    int openOrders(WorkOrder out[], int maxCount) const { return orders.toSortedArray(out, maxCount); }
    int resolvedOrders(WorkOrder out[], int maxCount) const { return history.toArray(out, maxCount); }   // newest first
    int getNextId() const { return nextId; }
    void clearAll();
    // done[] must be newest first, as resolvedOrders() gives it
    void restore(const WorkOrder open[], int openCount, const WorkOrder done[], int doneCount, int next);
};

#endif
