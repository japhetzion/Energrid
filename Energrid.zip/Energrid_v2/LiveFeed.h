// LiveFeed.h - taking in LIVE DATA (part of module 02, Energy Control)
//
// Live readings are a load in kW for each building. Where they come from is
// hidden behind an abstract base class, DataSource:
//
//   DataSource          abstract base class: says WHAT a source must do
//     SimulatedSource   child class: makes up realistic loads
//     FileSource        child class: reads the loads from a CSV file
//
// The LiveMonitor only talks to a DataSource*, so a new source (for example a
// real meter on a serial port) can be added later without changing it.
//
// Time is simulated: one tick = one hour. When 24 ticks have passed, the day
// closes and the energy used (kWh) is saved as that day's normal reading, so
// trends, alerts and reports all keep working.
#ifndef LIVEFEED_H
#define LIVEFEED_H

#include <string>
#include "CampusData.h"
#include "Settings.h"
using namespace std;

// ---------------------------------------------------------------
// DataSource: the abstract base class
// ---------------------------------------------------------------
class DataSource {
public:
    virtual ~DataSource() {}
    virtual string name() const = 0;

    // called once at the start of every tick (a file source reads its file here)
    virtual void startTick(int hour) = 0;

    // gives the load in kW for one building; false = no new value for it
    virtual bool getLoad(const Building* b, int hour, double& kw) = 0;
};

// ---------------------------------------------------------------
// SimulatedSource: makes up realistic loads. Academic blocks and labs use
// more during the day, hostels in the evening, and now and then a building
// has a three-hour spike.
// ---------------------------------------------------------------
class SimulatedSource : public DataSource {
    unsigned int seed;
    string names[MAX_BUILDINGS];
    int spikeLeft[MAX_BUILDINGS];     // hours of spike still to come, per building
    int known;

    int nextRandom();
    int spikeIndex(const string& name);

public:
    SimulatedSource(unsigned int startSeed);
    string name() const { return "Simulated feed"; }
    void startTick(int hour);
    bool getLoad(const Building* b, int hour, double& kw);
};

// ---------------------------------------------------------------
// FileSource: reads a CSV file with one line per building, "Name,kW".
// The file is read again at every tick, so changing and saving it changes
// the live data. A first line such as "Building,kW" is ignored.
// ---------------------------------------------------------------
class FileSource : public DataSource {
    string path;
    string names[MAX_BUILDINGS];
    double loads[MAX_BUILDINGS];
    int known;

    void store(const string& name, double kw);

public:
    FileSource(const string& filePath) : path(filePath), known(0) {}
    string name() const { return "File feed (" + path + ")"; }
    void startTick(int hour);
    bool getLoad(const Building* b, int hour, double& kw);
};

// ---------------------------------------------------------------
// LiveMonitor: moves time forward, asks the source for every building,
// raises alerts for sustained overloads and closes each day.
// ---------------------------------------------------------------
class LiveMonitor {
    CampusData& data;
    Settings& settings;
    DataSource* source;      // the monitor owns it and deletes it
    int hour;                // 0 to 23
    int day;                 // simulated day number

    LiveMonitor(const LiveMonitor&);
    LiveMonitor& operator=(const LiveMonitor&);

public:
    LiveMonitor(CampusData& d, Settings& s, DataSource* src);
    ~LiveMonitor();

    int getHour() const { return hour; }
    int getDay() const { return day; }
    string sourceName() const { return source->name(); }

    // One tick = one simulated hour. Fills events[] with what happened
    // (alerts, closed days) and returns how many.
    int tick(string events[], int maxEvents);

    // The day that was still running is not saved
    void discardPartialDay();
};

#endif
