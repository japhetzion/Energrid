// Settings.h - MODULE 05 logic: Settings
// Privacy | Permissions | Notifications | Appearance | Themes
// (the window for this module is gui/SettingsPage)
#ifndef SETTINGS_H
#define SETTINGS_H

#include <string>
#include <stdexcept>
using namespace std;

enum Role { ROLE_VIEWER = 1, ROLE_TECHNICIAN = 2, ROLE_ADMIN = 3 };

class Settings {
    Role role;
    string user;          // name of the logged-in user
    bool notificationsOn;
    int alertPercent;     // alert when a reading is above limit x percent / 100
    bool privacyMode;     // hide building names in reports and exports
    bool compactView;     // dashboard without the graphs
    int theme;            // 1 = Ocean, 2 = Forest, 3 = Violet

public:
    Settings();

    // getters used by the other modules
    Role getRole() const { return role; }
    string getUser() const { return user; }
    void setUser(const string& name) { user = name; }
    bool notificationsEnabled() const { return notificationsOn; }
    int getAlertPercent() const { return alertPercent; }
    bool isPrivacyMode() const { return privacyMode; }
    bool isCompact() const { return compactView; }
    int getTheme() const { return theme; }

    string roleName() const;
    string themeName() const;

    // permission checks (throw an exception if not allowed)
    void requireAdmin() const;   // Admin only
    void requireStaff() const;   // Technician or Admin

    // setters. A setter does nothing if the value is unchanged.
    void setRole(Role r);                  // anyone (simulates logging in as another user)
    void setNotifications(bool on);        // Admin only
    void setAlertPercent(int percent);     // Admin only, 50 to 150
    void setPrivacyMode(bool on);          // Admin only
    void setCompact(bool on);              // anyone
    void setTheme(int t);                  // anyone, 1 to 3
};

#endif
