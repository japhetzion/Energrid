// SettingsPage.h - MODULE 05: Settings (the screen)
// Privacy | Permissions (accounts) | Notifications | Appearance | Themes
// The settings themselves are stored in the Settings class (Settings.h),
// the users and passwords in the AccountManager (Accounts.h).
#ifndef SETTINGSPAGE_H
#define SETTINGSPAGE_H

#include "Page.h"
#include "Accounts.h"

class SettingsPage : public Page {
    AccountManager& accounts;

    void showMenu() const;
    void togglePrivacy();
    void accountsMenu();
    void notificationsMenu();
    void toggleAppearance();
    void chooseTheme();

    // accounts
    void changeMyPassword();
    void listUsers() const;
    void addUser();
    void removeUser();
    void resetPassword();
    void changeRole();

public:
    SettingsPage(CampusData& d, Settings& s, AccountManager& a) : Page(d, s), accounts(a) {}
    string name() const { return "Settings"; }
    void run();
};

#endif
