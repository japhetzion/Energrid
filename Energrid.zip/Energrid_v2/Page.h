// Page.h - the BASE CLASS of the five module screens (inheritance).
// DashboardPage, EnergyControlPage, MaintenancePage, ReportsPage and
// SettingsPage all inherit from Page. main() keeps them in one array of
// Page* and calls run() on whichever the user picks (polymorphism).
#ifndef PAGE_H
#define PAGE_H

#include <string>
#include "CampusData.h"
#include "Settings.h"
#include "Ui.h"
using namespace std;

class Page {
protected:
    CampusData& data;
    Settings& settings;

    // Clears the screen and draws the top of a page: the title, the current
    // role and the number of waiting alerts. The same for every page.
    void header(const string& pageTitle, bool clear = true) const {
        if (clear)
            clearScreen();
        drawTop(pageTitle);
        string alertText = "Alerts: " + to_string(data.alerts.size());
        string who = settings.getUser().empty()
            ? "Role: " + settings.roleName()
            : "User: " + settings.getUser() + " (" + settings.roleName() + ")";
        drawRowSplit(paint(who, GREY),
                     paint(alertText, data.alerts.size() > 0 ? AMBER : GREY));
        drawMiddle();
    }

    // A small page that explains what to type, shown before asking for input
    void inputScreen(const string& pageTitle, const string& hint) const {
        header(pageTitle);
        drawWrapped(hint);
        drawBottom();
    }

public:
    Page(CampusData& d, Settings& s) : data(d), settings(s) {}
    virtual ~Page() {}

    virtual string name() const = 0;    // the name shown in the main menu
    virtual void run() = 0;             // the page's own menu loop
};

#endif
