ENERGRID v2 - Campus Energy Analyser (C++ console application)

HOW TO RUN IN VISUAL STUDIO
  1. Create a new project: Console App (C++). Name it Energrid.
  2. Delete the default .cpp file Visual Studio creates (Remove > Delete).
  3. Right-click the project > Add > Existing Item, select ALL the .h and .cpp
     files from this folder (not the .txt files) and click Add.
  4. Press Ctrl+F5.
  Use Windows 10 or 11. The look needs colours and box characters; if they look
  wrong in the old console window, run it from Windows Terminal instead.

LOGIN
  The program asks for a username and password (3 attempts). On the very first start
  these accounts are created:
      admin  / admin123   Admin       (everything, including users and settings)
      user   / user123    Technician  (enter readings, live feed, work orders)
      viewer / viewer123  Viewer      (look at everything, report issues)
  Change these passwords at once: Settings > Permissions > Change my password.
  An Admin can add and remove users, reset passwords and change roles there too.
  Main menu: 9 = Log out (back to the login screen), 0 = Exit.
  The accounts are kept in energrid_users.txt (only hashes, never the passwords).
  If you forget every Admin password: delete energrid_users.txt, and the three starting
  accounts above are created again at the next start.

LIVE DATA (Energy Control > option 9)
  - Simulated feed: nothing to prepare. Choose source 1, 1 second per hour, 0 hours
    (runs until you press a key), or e.g. 48 hours to watch two days.
  - File feed: copy live_feed.csv into the PROJECT FOLDER (the folder with the .cpp
    files; Visual Studio runs the program from there). Choose source 2. Open the
    file in Notepad while it runs, change a number, save: the screen follows.

SAVING
  Your data is saved automatically to energrid_data.txt (in the project folder) every
  time you leave a menu and when you exit, and loaded again when the program starts.
  Main menu: 7 = save now, 8 = erase all data (asks you to type YES).
  If the file is damaged, the program keeps a copy as energrid_data.txt.bad and starts
  empty. To start completely fresh, use option 8 or delete energrid_data.txt.

FIRST THINGS TO TRY
  Welcome screen > any key > main menu > option 6 "Load sample data" > Dashboard
  > Energy Control > 9 (live data feed).

FILES TO ADD TO THE PROJECT: 17 .h files and 12 .cpp files = 29 files.
(live_feed.csv is a data file, not code: put it in the project folder, do not add it.)

Read EXPLANATION.txt for what every file does and how to explain it.
