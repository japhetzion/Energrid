// CampusData.h - the data every module shares
#ifndef CAMPUSDATA_H
#define CAMPUSDATA_H

#include <string>
#include <stdexcept>
#include "Building.h"
#include "Containers.h"
#include "DataStructures.h"
using namespace std;

struct CampusData {
    // Declared in this order so the list (which owns the buildings)
    // is destroyed last.
    BuildingList list;          // linked list : all buildings
    BuildingTable table;        // hash table  : find a building by name
    Queue<string> alerts;       // queue       : alerts, oldest first
    Stack<string> undoStack;    // stack       : buildings that got a reading (for Undo)
    PowerGrid grid;             // graph       : the power network

    // Adds a building to both the list and the hash table.
    // If anything fails, the building is deleted and the error is passed on.
    void addBuilding(Building* b) {
        try {
            if (list.getSize() >= MAX_BUILDINGS)
                throw runtime_error("Building limit reached.");
            if (b->getName().find('|') != string::npos)      // | is used in the saved file
                throw invalid_argument("The character | is not allowed in names.");
            table.insert(b);   // throws if the name already exists
        } catch (...) {
            delete b;
            throw;
        }
        list.add(b);
    }

    void removeBuilding(const string& name) {
        table.remove(name);
        list.remove(name);
    }

    // Empties everything (used by "Erase all data")
    void clearAll() {
        while (list.getHead() != NULL)
            removeBuilding(list.getHead()->data->getName());
        alerts.clear();
        while (!undoStack.isEmpty())
            undoStack.pop();
        grid.clear();
    }

    // Returns true if the reading is above the alert trigger
    // (limit x percent / 100). If queueIt is true, an alert message
    // is also added to the alert queue.
    bool raiseAlertIfHigh(Building* b, int day, double kwh, int percent, bool queueIt) {
        double trigger = b->getLimit() * percent / 100.0;
        if (kwh <= trigger)
            return false;
        if (queueIt)
            alerts.enqueue(b->getName() + ": Day " + to_string(day) + " used " +
                           to_string((int)kwh) + " kWh (limit " +
                           to_string((int)b->getLimit()) + ")");
        return true;
    }
};

#endif
