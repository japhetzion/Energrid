// PriorityQueue.h - a TEMPLATE class: written once, works for any type T.
//
// A priority queue always gives back the MOST URGENT item first, not the
// oldest one. It is built on a heap stored in an array:
//   - position 1 is the root (the most urgent item)
//   - the children of position i are at 2i and 2i+1, its parent at i/2
//
// T must have an operator> that says "this one is more urgent than that one".
// Energrid uses it twice:
//   PriorityQueue<BuildingRank, 100>  - which building needs attention first
//   PriorityQueue<WorkOrder, 100>     - which work order to handle first
#ifndef PRIORITYQUEUE_H
#define PRIORITYQUEUE_H

#include <stdexcept>
using namespace std;

template <typename T, int CAPACITY>
class PriorityQueue {
    T items[CAPACITY + 1];    // index 0 is not used
    int count;

public:
    PriorityQueue() : count(0) {}

    bool isEmpty() const { return count == 0; }
    int size() const { return count; }

    // Add an item: put it at the end, then move it UP while it is more
    // urgent than its parent.
    void push(const T& item) {
        if (count >= CAPACITY)
            throw runtime_error("The priority queue is full.");
        count++;
        int i = count;
        items[i] = item;
        while (i > 1 && items[i] > items[i / 2]) {
            T temp = items[i];
            items[i] = items[i / 2];
            items[i / 2] = temp;
            i = i / 2;
        }
    }

    // Look at the most urgent item without removing it.
    const T& top() const {
        if (isEmpty())
            throw runtime_error("The priority queue is empty.");
        return items[1];
    }

    // Remove and return the most urgent item: move the last item to the
    // top, then move it DOWN while a child is more urgent.
    T pop() {
        if (isEmpty())
            throw runtime_error("The priority queue is empty.");
        T best = items[1];
        items[1] = items[count];
        count--;
        int i = 1;
        while (true) {
            int biggest = i;
            int left = 2 * i;
            int right = 2 * i + 1;
            if (left <= count && items[left] > items[biggest])
                biggest = left;
            if (right <= count && items[right] > items[biggest])
                biggest = right;
            if (biggest == i)
                break;
            T temp = items[i];
            items[i] = items[biggest];
            items[biggest] = temp;
            i = biggest;
        }
        return best;
    }

    // Copies all items into out[], most urgent first, WITHOUT changing this
    // queue (it works on a copy of the queue).
    int toSortedArray(T out[], int maxCount) const {
        PriorityQueue<T, CAPACITY> copy = *this;
        int n = 0;
        while (!copy.isEmpty() && n < maxCount)
            out[n++] = copy.pop();
        return n;
    }
};

#endif
