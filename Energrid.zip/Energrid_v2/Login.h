// Login.h - the login screen
#ifndef LOGIN_H
#define LOGIN_H

#include <string>
#include "Accounts.h"
#include "Settings.h"
using namespace std;

// Asks for a username and password (3 attempts). On success the role and the
// name are put into the settings and true is returned. False means the user
// chose to quit, or failed 3 times. "notice" is a message shown on the screen.
bool showLogin(AccountManager& accounts, Settings& settings, const string& notice = "");

#endif
