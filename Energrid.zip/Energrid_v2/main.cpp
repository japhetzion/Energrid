// main.cpp - ENERGRID: Campus Energy Analyser
//
// The five modules (each one is a class that inherits from Page):
//   01 Dashboard                      DashboardPage
//   02 Energy Control                 EnergyControlPage (+ LiveFeed.h: live data)
//   03 Maintenance & Troubleshooting  MaintenancePage
//   04 Reports                        ReportsPage
//   05 Settings                       SettingsPage (+ Settings, Accounts)
//
// Shared files: Building.h, DataStructures.h, Containers.h, PriorityQueue.h,
//               CampusData.h, Page.h, Ui.h / Ui.cpp
// Saving:       Storage.h / Storage.cpp (the data file energrid_data.txt)
// Login:        Accounts.h / Accounts.cpp, Login.h / Login.cpp (energrid_users.txt)

#include <iostream>
#include <cstdio>
#include "Ui.h"
#include "CampusData.h"
#include "Settings.h"
#include "Page.h"
#include "DashboardPage.h"
#include "EnergyControlPage.h"
#include "MaintenancePage.h"
#include "ReportsPage.h"
#include "SettingsPage.h"
#include "Storage.h"
#include "Accounts.h"
#include "Login.h"
using namespace std;

// Adds one building with a week or more of readings (for demos)
void addSample(CampusData& data, Settings& settings,
               Building* b, const double values[], int n) {
    data.addBuilding(b);    // deletes b and throws if the name already exists
    for (int i = 0; i < n; i++) {
        b->addReading(values[i]);
        data.raiseAlertIfHigh(b, i + 1, values[i],
                              settings.getAlertPercent(),
                              settings.notificationsEnabled());
    }
}

void loadSampleData(CampusData& data, Settings& settings) {
    settings.requireAdmin();
    const double blockA[]  = {330, 345, 360, 372, 395, 410, 425, 440};
    const double hostelB[] = {220, 215, 230, 240, 255, 260, 270, 280};
    const double labC[]    = {480, 470, 465, 450, 455, 440, 430, 425};
    const double library[] = {200, 205, 198, 202, 200, 204, 199, 201};

    addSample(data, settings, new AcademicBlock("Block A"), blockA, 8);
    addSample(data, settings, new Hostel("Hostel B"), hostelB, 8);
    addSample(data, settings, new Lab("Lab C"), labC, 8);
    addSample(data, settings, new AcademicBlock("Library"), library, 8);

    // the power network (graph): who feeds whom
    data.grid.addLink("Main Substation", "Feeder 1");
    data.grid.addLink("Main Substation", "Feeder 2");
    data.grid.addLink("Feeder 1", "Block A");
    data.grid.addLink("Feeder 1", "Library");
    data.grid.addLink("Feeder 2", "Hostel B");
    data.grid.addLink("Feeder 2", "Lab C");
}

// Saves everything. If it fails, the user is told, but the program keeps running.
bool saveAll(const CampusData& data, const Settings& settings, const MaintenancePage& maintenance) {
    try {
        Storage::save(SAVE_FILE, data, settings, maintenance);
        return true;
    } catch (exception& e) {
        showError(string("Could not save: ") + e.what());
        pauseScreen();
        return false;
    }
}

// Keeps a damaged file under another name, so it is not overwritten
static void keepDamagedCopy(const string& file) {
    string badFile = file + ".bad";
    std::remove(badFile.c_str());
    std::rename(file.c_str(), badFile.c_str());
}

void showMainMenu(const CampusData& data, const Settings& settings, Page* pages[], int pageCount) {
    clearScreen();
    drawTop("ENERGRID  " + DOT + "  Campus Energy Analyser");
    string alertText = "Alerts: " + to_string(data.alerts.size());
    drawRowSplit(paint("User: " + settings.getUser() + " (" + settings.roleName() + ")", GREY),
                 paint(alertText, data.alerts.size() > 0 ? AMBER : GREY));
    drawMiddle();
    drawRow();
    for (int i = 0; i < pageCount; i++)
        drawMenuItem(to_string(i + 1), pages[i]->name());   // polymorphism: each page gives its own name
    drawMenuItem("6", "Load sample data");
    drawMenuItem("7", "Save data now");
    drawMenuItem("8", "Erase all data");
    drawMenuItem("9", "Log out");
    drawMenuItem("0", "Exit");
    drawRow();
    drawBottom();
}

int main() {
    initConsole();
    showWelcome();                            // "WELCOME TO ENERGRID" + press any key

    CampusData data;
    Settings settings;
    AccountManager accounts(USERS_FILE);
    setUiTheme(settings.getTheme());

    // the five modules, all held as Page* (base class pointers)
    const int PAGE_COUNT = 5;
    Page* pages[PAGE_COUNT];
    pages[0] = new DashboardPage(data, settings);
    pages[1] = new EnergyControlPage(data, settings);
    MaintenancePage* maintenance = new MaintenancePage(data, settings);
    pages[2] = maintenance;
    pages[3] = new ReportsPage(data, settings);
    pages[4] = new SettingsPage(data, settings, accounts);

    // load the saved data (nobody is logged in yet, so the settings can be set freely)
    try {
        if (Storage::load(SAVE_FILE, data, settings, *maintenance)) {
            setUiTheme(settings.getTheme());
            showSuccess("Saved data loaded: " + to_string(data.list.getSize()) + " building(s), " +
                        to_string(data.alerts.size()) + " alert(s).");
            pauseScreen();
        }
    } catch (exception& e) {
        data.clearAll();                       // start clean rather than with half a file
        maintenance->clearAll();
        keepDamagedCopy(SAVE_FILE);
        showError(string(e.what()) + "  Starting with empty data. The damaged file was kept as " +
                  SAVE_FILE + ".bad.");
        pauseScreen();
    }

    // load the accounts, or create the starting ones
    string notice;
    try {
        if (!accounts.load()) {
            accounts.createDefaults();
            notice = "First start: accounts were created.  admin / admin123 (Admin),  "
                     "user / user123 (Technician),  viewer / viewer123 (Viewer).  "
                     "Change these passwords in Settings > Permissions.";
        }
    } catch (exception& e) {
        keepDamagedCopy(USERS_FILE);
        accounts.createDefaults();
        notice = string(e.what()) + "  The damaged file was kept as " + USERS_FILE + ".bad.  "
                 "New starting accounts were created: admin / admin123, user / user123, "
                 "viewer / viewer123.";
    }

    bool quit = false;
    while (!quit) {
        if (!showLogin(accounts, settings, notice))
            break;                             // the user chose to quit, or failed to log in
        notice = "";

        int choice;
        do {
            showMainMenu(data, settings, pages, PAGE_COUNT);
            choice = readInt("Choose an option");
            if (choice >= 1 && choice <= PAGE_COUNT) {
                pages[choice - 1]->run();      // runs whichever page was chosen
                saveAll(data, settings, *maintenance);   // saved every time you leave a page
            } else if (choice == 6) {
                try {
                    loadSampleData(data, settings);
                    showSuccess("Sample data loaded: Block A, Hostel B, Lab C, Library and the power network.");
                    saveAll(data, settings, *maintenance);
                } catch (exception& e) {
                    showError(e.what());
                }
                pauseScreen();
            } else if (choice == 7) {
                if (saveAll(data, settings, *maintenance)) {
                    showSuccess("Data saved to " + SAVE_FILE + ".");
                    pauseScreen();
                }
            } else if (choice == 8) {
                try {
                    settings.requireAdmin();
                    string answer = readText("Type YES to erase all buildings, readings and work orders");
                    if (answer == "YES") {
                        data.clearAll();
                        maintenance->clearAll();
                        saveAll(data, settings, *maintenance);
                        showSuccess("All data was erased.");
                    } else {
                        showError("Cancelled. Nothing was erased.");
                    }
                } catch (exception& e) {
                    showError(e.what());
                }
                pauseScreen();
            } else if (choice != 0 && choice != 9) {
                showError("Please choose a number from the menu.");
                pauseScreen();
            }
        } while (choice != 0 && choice != 9);

        saveAll(data, settings, *maintenance);
        if (choice == 0)
            quit = true;                       // 9 = log out: go back to the login screen
    }

    for (int i = 0; i < PAGE_COUNT; i++)
        delete pages[i];

    clearScreen();
    cout << accent() << "Thank you for using Energrid." << RESET << "\n";
    return 0;
}
