// Storage.h - saving the data to a file and loading it back, so nothing is
// lost when the program is closed.
//
// This is NOT a database: it is one plain text file (energrid_data.txt) in a
// format Energrid writes and reads itself. Every line starts with a tag:
//
//   ENERGRID|1                                  header and version
//   SETTINGS|notifications|alert%|privacy|compact|theme
//   BUILDING|type|name|days|reading;reading;...
//   LINK|from|to                                the power network
//   ALERT|message                               waiting alerts, oldest first
//   ORDER|O or R|id|building|issue|priority     open / resolved work orders
//   NEXTID|number
//
// What is saved: buildings and their daily readings, the power network, the
// alerts, the work orders and the settings (except the role).
#ifndef STORAGE_H
#define STORAGE_H

#include <string>
#include "CampusData.h"
#include "Settings.h"
#include "MaintenancePage.h"
using namespace std;

const string SAVE_FILE = "energrid_data.txt";

class Storage {
public:
    // Writes everything to the file. The data is written to a temporary file
    // first, so a failure half-way never destroys the old save.
    static void save(const string& path, const CampusData& data, const Settings& settings,
                     const MaintenancePage& maintenance);

    // Reads the file into the (empty) data. Returns false if there is no file yet.
    // Throws an exception with the line number if the file is damaged.
    static bool load(const string& path, CampusData& data, Settings& settings,
                     MaintenancePage& maintenance);
};

#endif
